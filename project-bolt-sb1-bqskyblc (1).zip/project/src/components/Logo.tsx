import { cn } from '@/lib/utils';

export function Logo({ className, size = 36 }: { className?: string; size?: number }) {
  return (
    <div
      className={cn(
        'grid place-items-center rounded-xl bg-gradient-to-br from-teal-500 to-brand-500 text-white shadow-soft shrink-0',
        className
      )}
      style={{ width: size, height: size }}
    >
      <svg
        width={size * 0.58}
        height={size * 0.58}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M12 5v14M5 12h14" />
      </svg>
    </div>
  );
}

export function LogoWordmark({ className }: { className?: string }) {
  return (
    <div className={cn('flex items-center gap-2.5', className)}>
      <Logo size={34} />
      <div className="leading-none">
        <span className="font-display font-extrabold text-xl tracking-tight text-ink-900">
          MED
        </span>
        <span className="font-display font-extrabold text-xl tracking-tight text-teal-600">
          -ID
        </span>
      </div>
    </div>
  );
}
