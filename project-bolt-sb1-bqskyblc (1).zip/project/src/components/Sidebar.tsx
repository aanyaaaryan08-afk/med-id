import { type PageId } from '@/types';
import { LogoWordmark } from './Logo';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  Siren,
  GitBranch,
  Stethoscope,
  Pill,
  FolderHeart,
  UserCog,
  Watch,
  LogOut,
  X,
} from 'lucide-react';

const navItems: { id: PageId; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'emergency', label: 'Emergency', icon: Siren },
  { id: 'timeline', label: 'Medical Timeline', icon: GitBranch },
  { id: 'consultations', label: 'Consultations', icon: Stethoscope },
  { id: 'medications', label: 'Medications', icon: Pill },
  { id: 'records', label: 'Medical Records', icon: FolderHeart },
  { id: 'doctor-access', label: 'Doctor Access', icon: UserCog },
  { id: 'bracelet', label: 'MED-ID Bracelet', icon: Watch },
];

export function Sidebar({
  active,
  onNavigate,
  onLogout,
  open,
  onClose,
  patient,
}: {
  active: PageId;
  onNavigate: (id: PageId) => void;
  onLogout: () => void;
  open: boolean;
  onClose: () => void;
  patient?: import('@/types').Patient;
}) {
  return (
    <>
      {open && (
        <div
          className="fixed inset-0 bg-ink-900/40 backdrop-blur-sm z-30 lg:hidden animate-fade-in-fast"
          onClick={onClose}
        />
      )}
      <aside
        className={cn(
          'fixed lg:sticky top-0 z-40 h-screen w-72 shrink-0 bg-white border-r border-ink-200 flex flex-col transition-transform duration-300',
          open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        <div className="flex items-center justify-between px-5 h-16 border-b border-ink-100">
          <LogoWordmark />
          <button
            onClick={onClose}
            className="lg:hidden p-2 -mr-2 rounded-lg text-ink-500 hover:bg-ink-100"
            aria-label="Close menu"
          >
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto scrollbar-thin px-3 py-4 space-y-1">
          <p className="px-3 pb-2 text-[11px] font-bold uppercase tracking-wider text-ink-400">
            Medical Profile
          </p>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = active === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={cn(
                  'group flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200',
                  isActive
                    ? 'bg-teal-50 text-teal-700'
                    : 'text-ink-600 hover:bg-ink-50 hover:text-ink-800'
                )}
              >
                <Icon
                  size={18}
                  className={cn(isActive ? 'text-teal-600' : 'text-ink-400 group-hover:text-ink-600')}
                />
                <span>{item.label}</span>
                {isActive && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-teal-500" />}
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-ink-100">
          <div className="flex items-center gap-3 px-2 py-2 mb-2">
            <div className="h-9 w-9 rounded-full bg-gradient-to-br from-teal-500 to-brand-500 grid place-items-center text-white text-sm font-bold">
              {patient ? patient.name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase() : 'AM'}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-ink-800 truncate">{patient?.name ?? 'Aarav Mehta'}</p>
              <p className="text-xs text-ink-400 truncate font-mono">{patient?.medId ?? 'MED-102948'}</p>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 w-full px-3 py-2 rounded-xl text-sm font-medium text-ink-600 hover:bg-red-50 hover:text-red-600 transition-colors"
          >
            <LogOut size={16} />
            Sign out
          </button>
        </div>
      </aside>
    </>
  );
}
