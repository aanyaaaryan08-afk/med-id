import { type PageId } from '@/types';
import { Logo } from './Logo';
import { Menu, Siren, ShieldCheck } from 'lucide-react';

const titles: Record<PageId, { title: string; sub: string }> = {
  dashboard: { title: 'Patient Dashboard', sub: 'Overview of medical profile' },
  emergency: { title: 'Emergency Information', sub: 'Critical info for healthcare professionals' },
  timeline: { title: 'Medical Timeline', sub: 'Chronological medical history' },
  consultations: { title: 'Consultations', sub: 'All recorded consultations' },
  medications: { title: 'Medications', sub: 'Current and previous prescriptions' },
  records: { title: 'Medical Records', sub: 'Allergies, conditions, surgeries & more' },
  'doctor-access': { title: 'Doctor Access', sub: 'Authorized healthcare professional access' },
  bracelet: { title: 'MED-ID Bracelet', sub: 'Physical identification concept' },
};

export function Topbar({
  page,
  onMenu,
  onEmergency,
}: {
  page: PageId;
  onMenu: () => void;
  onEmergency: () => void;
}) {
  const t = titles[page];
  return (
    <header className="sticky top-0 z-20 bg-white/80 backdrop-blur-md border-b border-ink-100">
      <div className="flex items-center justify-between gap-3 px-4 sm:px-6 h-16">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onMenu}
            className="lg:hidden p-2 -ml-2 rounded-lg text-ink-600 hover:bg-ink-100"
            aria-label="Open menu"
          >
            <Menu size={22} />
          </button>
          <div className="lg:hidden">
            <Logo size={32} />
          </div>
          <div className="hidden sm:block min-w-0">
            <h2 className="font-display font-bold text-ink-900 truncate">{t.title}</h2>
            <p className="text-xs text-ink-500 truncate">{t.sub}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center gap-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-full">
            <ShieldCheck size={14} />
            Prototype
          </div>
          <button
            onClick={onEmergency}
            className="btn-danger px-4 py-2 text-sm animate-pulse-ring"
          >
            <Siren size={16} />
            <span className="hidden sm:inline">Emergency Mode</span>
            <span className="sm:hidden">Emergency</span>
          </button>
        </div>
      </div>
    </header>
  );
}
