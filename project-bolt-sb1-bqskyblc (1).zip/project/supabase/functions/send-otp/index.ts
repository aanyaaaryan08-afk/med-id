import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function genOtp(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { patient_med_id, phone, purpose } = await req.json();

    if (!patient_med_id || !phone) {
      return new Response(
        JSON.stringify({ error: "patient_med_id and phone are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const otp = genOtp();
    const purposeLabel = purpose || "patient_access";

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const insertRes = await fetch(`${supabaseUrl}/rest/v1/otp_codes`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: serviceKey,
        Authorization: `Bearer ${serviceKey}`,
        Prefer: "return=representation",
      },
      body: JSON.stringify({
        patient_med_id,
        code: otp,
        purpose: purposeLabel,
        phone_used: phone,
        expires_at: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
      }),
    });

    if (!insertRes.ok) {
      return new Response(
        JSON.stringify({ error: "Failed to store OTP" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const twoFactorKey = Deno.env.get("TWO_FACTOR_API");
    const realSmsConfigured = !!twoFactorKey;

    let smsSent = false;
    let demoMode = true;

    if (realSmsConfigured) {
      demoMode = false;
      try {
        const smsRes = await fetch(
          `https://2factor.in/API/V1/${twoFactorKey}/SMS/${phone}/${otp}`,
          { method: "GET" }
        );
        smsSent = smsRes.ok;
      } catch {
        smsSent = false;
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        demo_mode: demoMode,
        sms_sent: smsSent,
        demo_code: demoMode ? otp : undefined,
        message: demoMode
          ? "DEMO MODE — SMS NOT ENABLED. Configure TWO_FACTOR_API secret to send real SMS."
          : smsSent
          ? "OTP sent via SMS to the patient's registered phone number."
          : "We couldn't send the OTP right now. Please try again.",
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch {
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
